from .base import *

SECRET_KEY = 's%z)7nukh=j)q97i&)_8asn*$rr3&gv$tv2)=)qn4vchx72j97'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []